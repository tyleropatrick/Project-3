#pragma once
#include <string>
#include "Game.h"
#include "teamList.h"
#include <fstream>

class gameList {
public:
	//Constuctor
	gameList();
	//Creates function calls
	void addGame(game g);
	void readGame(teamList l);
	int getNumWins(team * t);
	int getNumGames();
	int getNumLosses(team * t);
	void printGames(team * t);
	void writeGames();


private:
	//Creates Pointers
	game * head;
	game * tail;

};