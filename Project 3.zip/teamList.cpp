#include "teamList.h"

void doAbort(string errMsg);
teamList::teamList()
{
	head = NULL;

}//teamList

void teamList::addTeam(team t)
{
	team *n = new team; // Allocate new team
	n->teamID = t.getTeamID(); // Set data for team ID
	n->coach = t.getCoach(); // Set data for Coach
	n->name = t.getName();// Set data for Name
	n->next = head; //Add team to the list
	n->next = head;
	head = n; // Make n the new head

}
void teamList::readData()
{
	ifstream f;
	team t;// sets t to a team class
	f.open("teams.txt");// opens teams.txt

	if (f.fail())// Fail case
	{
		doAbort("ERROR: File \"teams.txt\" could not be opened!");
	}
	while (!f.eof())// while it is not the end of file
	{
		getline(f, t.teamID); // gets line of teamID
		getline(f, t.name);// gets line of name
		getline(f, t.coach);// gets line of coach

		addTeam(t);//adds team
	}
}
int teamList::getNumTeams()
{
	int numTeams = 0;
	team *n = head;//creates a pointer
	while (n != NULL)// while it is not at the end of the node
	{
		numTeams++;//increment numTeams by 1
		n = n->next;//moves to next node
	}
	return numTeams;//returns the numTeams
}

void teamList::printTeams()
{
	// Prints the teamlist
	cout << "---------------------------- TEAMS (" << getNumTeams() << ")------------------------------------" << endl;
	cout << "TID   TEAM                       COACH" << endl;
	cout << "----  -------------------------  --------------------" << endl;
	
	// Creates pointer and sets to head
	team * n = head;
	//while n is not at the end of the node
	while (n != NULL)
	{
		// prints team info
		cout << setw(4) << n->teamID << "  ";
		cout << setw(25) << n->name << "  ";
		cout << setw(20) << n->coach << endl;
		n = n->next; // sets to next node
	}
}//printTeams
team * teamList::getTeamRef(string tmID)
{
	team * p = head;// createes a head node
	while (p != NULL)
	{
		if (p->getTeamID() == tmID)
			return p;
		p = p->next;// sets to next node
	}
	return NULL;
}//getTeamRef




