#include "GameList.h"
// Includes GameList


void doAbort(string errMsg);// Creates promise for abort including a error message

gameList::gameList() // Class that sets head and tail to NULL
{
	head = NULL;
	tail = NULL;
}//gameList

void gameList::addGame(game g)
{
	game * newgame = new game; // Creates a pointer to a new game value
	newgame->set(g.getDate(),g.getTeam1(),g.getTeam2(),g.getT1pts(),g.getT2pts());// sets date, team 1, team 2, team 1 points, and team 2 points 

	game * p = head;// Creates a pointer for head
	if (head == NULL)// if statement that sets head and tail variable to newgame aslong as it has not reached the end of the node
	{
		head = newgame;
		tail = newgame;
		return;
	}
	while (p->next != NULL)// while loop that keeps the node going aslong as its not at the end
	{
		p = p->next;
	}
	

		p->next = newgame;// Sets the next value in the node to new game
		tail = newgame; // Sets tail value to newgame
	}//addGame


void gameList::readGame(teamList l)
{
	ifstream f; // allocates f to read data from a file
	string t1, t2, p1, p2; // initalizes variables
	game g;
	f.open("games.txt");// opens games.txt
	if (f.fail())//if it fails to open
		doAbort("ERROR: File \"games.txt\" could not be opened!");
	while(!f.eof())// while it is not the end of the file
	{
		//sets variables
		f >>g.date;
		f >> t1; 
		f >> g.t1pts;
		f >> t2;
		f >> g.t2pts;
		g.team1 = l.getTeamRef(t1);
		g.team2 = l.getTeamRef(t2);

		addGame(g);//adds game object

	}//readGame
}
int gameList::getNumGames()
{
	int numGames = 0;//initalizes numGames
	game * n = head;//Creates a head pointer
	while (n != NULL) //While n pointer does not equal NULL
	{
		numGames++;// increment the num of games by 1
		n = n->next; //sets n to next value in node
	}
	return numGames;// returns the number of games
}// gets the Num of Games

int gameList::getNumWins(team * t)
{
	int numWins = 0;//sets numWins to 0
	game * p = head;//creates a head pointer
	while (p != NULL)
	{
		//Checks Num wins for team1
		if (p->team1->getTeamID() == t->getTeamID())
			if (p->t1pts > p->t2pts)
				numWins++;
		//Checks Num wins for team2
		if (p->team2->getTeamID() == t->getTeamID())
			if (p->t2pts > p->t1pts)
				numWins++;
		p = p->next;
	}
	return numWins;
}// Num losses

int gameList::getNumLosses(team * t)
{
	//Sets num Losses
	int numLosses = 0;
	game * p = head;
	while (p != NULL)// while p is not the end of the line
	{
		//Checks num Losses for team 1
		if (p->team1->getTeamID() == t->getTeamID())
			if(p->t1pts < p->t2pts)
			numLosses++;
		//Checks num losses for team 2
		if (p->team2->getTeamID() == t->getTeamID())
			if (p->t2pts < p->t1pts)
				numLosses++;
		p = p->next;
	}
	return numLosses;
}

void gameList::printGames(team * t)
{
	game * p = head;
	// Prints header
	cout << "----------- GAMES (" << getNumGames() << ") ---------------" << endl;;
	cout << "DATE        TEAM  SC   TEAM  SC\n";
	cout << "----------  ----  ---  ----  --\n";

	// prints the date, teams, and team points
	while (p != NULL)
	{
		if (t == NULL)
		{
			cout << setw(10) << p->date << "  " << setw(4) << (p->getTeam1())->getTeamID() << "  " << setw(3) << p->getT1pts() << "  " << setw(4) << (p->getTeam2())->getTeamID() << "  " << setw(3) << p->getT2pts() << endl;

		}
		else if ((t->getTeamID() == p->team1->getTeamID()) || (t->getTeamID() == p->team2->getTeamID())) {
			cout << setw(10) << p->date << "  " << setw(4) << (p->getTeam1())->getTeamID() << "  " << setw(3) << p->getT1pts() << "  " << setw(4) << (p->getTeam2())->getTeamID() << "  " << setw(3) << p->getT2pts() << endl;
		 
		}
		p = p->next;
	}//PrintGames
}
void gameList::writeGames()
{
	ofstream f;
	f.open("games2.txt");//creates file called game2.txt or allocates too it
	game * p = head;
	while (p != NULL)//writes game information
	{
		f << p->getDate() << "  " << (p->getTeam1())->getTeamID() << "  " << p->getT1pts() << "  " << ((p->getTeam2())->getTeamID()) << "  " << p->getT2pts() << endl;
		p = p->next;
	}
	f.close();//closes the file
}//writeGames
