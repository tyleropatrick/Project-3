//-----------------------------------------------------------------
//By Tyler Patrick
//Date: 4/24/19
//Assistance: I received assitance from Josiah Jaddock
//-----------------------------------------------------------------

#include"league.h"
#include<iostream>
#include<string>
using namespace std;

void doAbort(string errMsg)// Function To abort
{
	cout << errMsg << endl;// Displays Error Message
	system("pause");
}//doAbort();
int main()
{
	cout << left;// Shifts print to the left
	league gameLeague;// creates league class for gameLeague
	gameLeague.go();//Runs gameLeague
	system("pause");//Creates a system pause at the end
	return 0;
}