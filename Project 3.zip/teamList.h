#pragma once
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include "team.h"

class teamList 
{
	friend class team;
public:
	// Creates constructor
	teamList();
	// Creates function calls
	void addTeam(team t);
	void readData();
	int getNumTeams();
	void printTeams();
	team * getTeamRef(string tmID);
private:
	// Creates pointer
	team * head;
};