#include "Game.h"

game::game()
{
	// sets variables
	date = "";
	t1pts = 0;
	t2pts = 0;
	team1 = NULL;
	team2 = NULL;
	next = NULL;
}//game()

void game::set(string d, team * t1, team * t2, int p1, int p2)
{
	// sets string and pointers
	date = d;
	team1 = t1;
	team2 = t2;
	t1pts = p1;
	t2pts = p2;
}//set

string game::getDate()
{
	return date;
}//getDate

int game::getT1pts()
{
	return t1pts;
}//getT1pts

int game::getT2pts()
{
	return t2pts;
}//getT2pts

team * game::getTeam1()
{
	return team1;
}//getTeam1

team * game::getTeam2()
{
	return team2;
}//getTeam2

