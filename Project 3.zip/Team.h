#pragma once


#include <iostream>
#include <string>

using namespace std;

class team {
	// Creates friend class for teamList
	friend class teamList;
	public:
		//Constructor
		team();
		//Sets strings
		string getTeamID();
		string getName();
		string getCoach();

		//Creates functions
		void setTeamID(string ID);
		void setName(string n);
		void setCoach(string c);

		private:

	//Creates Variables
	string teamID, name, coach;
	team * next;

	
};
