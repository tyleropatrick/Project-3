#include "Team.h"
team::team()
{
	teamID = " ";
	name = " ";
	coach = " ";
	next = NULL;
}

string team::getTeamID()
{
	return teamID;
}

string team::getName()
{
	return name;
}

string team::getCoach()
{
	return coach;
}

void team::setTeamID(string ID)
{
	teamID = ID;
}

void team::setName(string n)
{
	name = n;
}

void team::setCoach(string c)
{
	coach = c;
}
