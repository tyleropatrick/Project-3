#pragma once
#include <string>
#include "Team.h"

using namespace std;

class game {
	friend class gameList;
public:
	//Constructor
	game();
	//Creates function calls 
	void set(string date, team * t1, team * t2, int p1, int p2);
	string getDate();
	int getT1pts();
	int getT2pts();
	team * getTeam1();
	team * getTeam2();
private:
	//Sets variables and pointers
	string date;
	int t1pts, t2pts;
	team * team1;
	team * team2;
	game * next;
};